export class Mapmodel {
    CATEGORY: string;
    LATITUDE: number;
    LONGITUDE: number;
}