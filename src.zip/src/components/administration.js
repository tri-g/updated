import React,{ Component } from 'react';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import './administration.css';
import 'bootstrap/dist/css/bootstrap.css';
export default class Administrationsection extends Component {


render(){
	return(
<div className="container">

 <ul className="nav nav-tabs left-tabs">
  <li className="nav-item">
    <a className="nav-link" href="#tab-panel-1" data-toggle="tab">Our Ethos</a>
  </li>
  <li className="nav-item">
    <a className="nav-link" href="#tab-panel-2" data-toggle="tab">Our People</a>
  </li>
  <li className="nav-item">
    <a className="nav-link" href="#tab-panel-3" data-toggle="tab">Our Customers</a>
  </li>
  <li className="nav-item">
    <a className="nav-link" href="#tab-panel-4" data-toggle="tab">Our Impact</a>
  </li>
  <li className="nav-item">
    <a className="nav-link" href="#tab-panel-5" data-toggle="tab">Our Evolution</a>
  </li>
  <li className="nav-item">
    <a className="nav-link" href="#tab-panel-6" data-toggle="tab">Our Learning</a>
  </li>

</ul>
<div className="card">
<div className="tab-content">
  <article className="tab-pane container" id="tab-panel-1">
   Our Ethos
  </article>
  <article className="tab-pane container" id="tab-panel-2">
    Our People
  </article>
  <article className="tab-pane container" id="tab-panel-3">
    <Tabs className="tabs">

    <TabList>
    <Tab>Customer Details</Tab>
    &nbsp; &nbsp;
    <Tab>Customer Journey</Tab>
    &nbsp; &nbsp;
    <Tab>Customer Projects</Tab>
    &nbsp; &nbsp;
    <Tab>Customer Project Team</Tab>
    </TabList>

    <TabPanel>
     Customer Details, form to be implemented
    </TabPanel>
    <TabPanel>
      Customer Journey,form to be implemented
    </TabPanel>
    <TabPanel>
      Customer Projects, form to be implemented 
    </TabPanel>
    <TabPanel>
    Customer Project Team, form to be implemented 
    </TabPanel>

  </Tabs>





















  </article>
  <article className="tab-pane container" id="tab-panel-4">
    Our Impact
  </article>
  <article className="tab-pane container" id="tab-panel-5">
    Our Evolution
  </article>
  <article className="tab-pane container" id="tab-panel-6">
    Our Learning
  </article>
</div>
</div>
	</div>	










		)


}















	}