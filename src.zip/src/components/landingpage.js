import React from 'react';
import { render } from 'react-dom';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
import './landingpage.css';
import Uploadsection from './upload.js';
import Administrationsection from './administration.js'

const Landingpage = () => {
  return (
    <div id="id1">
    
    <Tabs>

    <TabList>
      <Tab>Upload</Tab>
      &nbsp; &nbsp;
      <Tab>My Videos</Tab>
       &nbsp; &nbsp;
      <Tab>Approval Management</Tab>
       &nbsp; &nbsp;
      <Tab>Administartion</Tab>
    </TabList>

    <TabPanel>
     <Uploadsection/>
    </TabPanel>
    <TabPanel>
      <h2>videos will be dislayed, to be implemented</h2>
    </TabPanel>
    <TabPanel>
      <h2>approval management, to be implemented </h2>
    </TabPanel>
    <TabPanel>
     <Administrationsection/>
    </TabPanel>

  </Tabs>
  </div>
  );
};

export default Landingpage;