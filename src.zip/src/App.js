import './App.css';
import Landingpage from './components/landingpage.js'
function App() {
  return (
    <div className="App">
      <Landingpage/>
    </div>
  );
}

export default App;
