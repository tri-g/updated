import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import more from 'highcharts/highcharts-more';
more(Highcharts);
import HighchartsNetworkgraph from 'highcharts/modules/networkgraph'; 
HighchartsNetworkgraph(Highcharts);
import { ResultModel } from './../result-model';
import { PersonaService } from '../persona.service';
import {Demographics} from "./../demo";

@Component({
  selector: 'app-dynamic-chart',
  templateUrl: './dynamic-chart.component.html',
  styleUrls: ['./dynamic-chart.component.css']
})
export class DynamicChartComponent implements OnInit {
 public message:any;
 public id:any;
  public name:any;
 
   public CategoryModel: ResultModel[];
    title = "Categories";
    chart;
    updateFromInput = false;
    Highcharts = Highcharts;
    chartConstructor = "chart";
    chartCallback;
    chartCallback1;
    chartOptions = {
      chart: {
        type: "networkgraph",
      },
      title: {
        text: "Categories Based On Total Money Spent"
      },
      
      plotOptions: {
        networkgraph: {
          keys: ["from", "to"],
          layoutAlgorithm: {
            enableSimulation: true,

          }
        }
      },
      series: [],
      tooltip:{}
    };

    constructor(private pservice: PersonaService) {
      const self = this;
      this.chartCallback = chart => {
        self.chart = chart;
        this.onInitChart();
      };
    }
   ngOnInit() {

  }

   onInitChart() {

   this.message=this.pservice.readMessage();
      console.log("hey im here!!!!!!!!!!!!!!!!!!!");
      console.log(this.message);
     for(let details of this.message){
     this.id=details.client_id;
     this.name=details.first;
     }


console.log(this.id);
  this.pservice.categorytop5(this.id).subscribe(
    response => {
    
        this.CategoryModel = response;
        console.log("this.CategoryModel");
        console.log(this.CategoryModel);
      });
    


        const self = this,
        chart = this.chart;

        chart.showLoading();

        setTimeout(() => {
          chart.hideLoading();
    
          self.chartOptions.series = [
            {
                dataLabels: {
                  enabled: true,

                  linkFormat: '',
                  allowOverlap: false,
                  showInLegend: true,
                  align:'center',
                   style: {
                    textOutline: false 
                }
                },
               

                marker: {
                    radius: 55,
                  },
                nodes: [
                   
                   {
                    id: this.CategoryModel[0].CATEGORY,
                    color: 'green',
                    name:this.CategoryModel[0].CATEGORY+'<br/> Amount : '+this.CategoryModel[0].AMOUNT
                   
                  }, {
                    id: this.CategoryModel[1].CATEGORY,
                    color: 'red',
                    name:this.CategoryModel[1].CATEGORY+'<br/> Amount : '+this.CategoryModel[1].AMOUNT
                  },
                  {
                    id: this.CategoryModel[2].CATEGORY,
                    color: 'orange',
                    name:this.CategoryModel[2].CATEGORY+'<br/> Amount : '+this.CategoryModel[2].AMOUNT
                  },
                  {
                    id: this.CategoryModel[3].CATEGORY,
                    color: 'yellow',
                    name:this.CategoryModel[3].CATEGORY+'<br/> Amount : '+this.CategoryModel[3].AMOUNT
                  },
                  {
                    id: this.CategoryModel[4].CATEGORY,
                    color: 'violet',
                    name:this.CategoryModel[4].CATEGORY+'<br/> Amount : '+this.CategoryModel[4].AMOUNT
                  },
                   {
                    id: this.CategoryModel[0].BILLING_PLACE,
                    color: 'pink',
                    name:'Place : '+this.CategoryModel[0].BILLING_PLACE+'<br/> Max_amount : '+this.CategoryModel[0].MAX_AMOUNT,
                     marker: {
                    radius: 10,
                  }
                  },
                  {
                    id: this.CategoryModel[1].BILLING_PLACE,
                    color: 'pink',
                    name:'Place : '+this.CategoryModel[1].BILLING_PLACE+'<br/> Max_amount : '+this.CategoryModel[1].MAX_AMOUNT,
                     marker: {
                    radius: 10,
                  },
                  },
                  {
                    id: this.CategoryModel[2].BILLING_PLACE,
                    color: 'pink',
                    name:'Place : '+this.CategoryModel[2].BILLING_PLACE+'<br/> Max_amount : '+this.CategoryModel[2].MAX_AMOUNT,
                     marker: {
                    radius: 10,
                  }
                  },
                  {
                    id: this.CategoryModel[3].BILLING_PLACE,
                    color: 'pink',
                    name:'Place : '+this.CategoryModel[3].BILLING_PLACE+'<br/> Max_amount : '+this.CategoryModel[3].MAX_AMOUNT,
                     marker: {
                    radius: 10,
                  }
                  },
                  {
                    id: this.CategoryModel[4].BILLING_PLACE,
                    color: 'pink',
                    name:'Place : '+this.CategoryModel[4].BILLING_PLACE+'<br/> Max_amount : '+this.CategoryModel[4].MAX_AMOUNT,
                     marker: {
                    radius: 10,
                  },
                  align:'left'
                  },
                  ],
                data: [
                {from:this.name, to:this.CategoryModel[0].CATEGORY},
                 {from:this.name, to:this.CategoryModel[1].CATEGORY},
                  {from:this.name, to:this.CategoryModel[2].CATEGORY},
                 {from:this.name, to:this.CategoryModel[3].CATEGORY},
                  {from:this.name, to:this.CategoryModel[4].CATEGORY},
                  {from:this.CategoryModel[0].CATEGORY,to:this.CategoryModel[0].BILLING_PLACE},
                  {from:this.CategoryModel[1].CATEGORY,to:this.CategoryModel[1].BILLING_PLACE},
                  {from:this.CategoryModel[2].CATEGORY,to:this.CategoryModel[2].BILLING_PLACE},
                  {from:this.CategoryModel[3].CATEGORY,to:this.CategoryModel[3].BILLING_PLACE},
                  {from:this.CategoryModel[4].CATEGORY,to:this.CategoryModel[4].BILLING_PLACE},
                 
                
                ]
              }
          ];
    
          self.updateFromInput = true;
        }, 2000);

      }
  }
