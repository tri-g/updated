var mysql      = require('mysql2');
var connection = mysql.createConnection({
host     : 'localhost', 
  user     : 'root', 
  password : 'root', 
  database : 'dcp'
  });
  connection.connect(function(err) {
  if (err) throw err
  console.log('You are now connected...')
})
  
exports.listall = (req, res) => {
connection.query('select * from demographics_with_product_id', function (error, results, fields) {
    if (error) throw error;
    res.end(JSON.stringify(results));
  });
};

exports.listbyid = (req, res) => {
 console.log(req);
   connection.query('select * from demographics_with_product_id where client_id=?', [req.params.client_id], function (error, results, fields) {
    if (error) throw error;
    res.end(JSON.stringify(results));
  });
};
exports.listbyfirst = (req, res) => {
 console.log(req);
   connection.query('select * from demographics_with_product_id where first=?', [req.params.first], function (error, results, fields) {
    if (error) throw error;
    res.end(JSON.stringify(results));
  });
};
exports.listbylast = (req, res) => {
 console.log(req);
   connection.query('select * from demographics_with_product_id where last=?', [req.params.last], function (error, results, fields) {
    if (error) throw error;
    res.end(JSON.stringify(results));
  });
};
exports.listbyemail = (req, res) => {
 console.log(req);
   connection.query('select * from demographics_with_product_id where email=?', [req.params.email], function (error, results, fields) {
    if (error) throw error;
    res.end(JSON.stringify(results));
  });
};
exports.listcid = (req, res) => {
   connection.query('select client_id,first,last,email from demographics_with_product_id ',function (error, results, fields) {
    if (error) throw error;
    res.end(JSON.stringify(results));
  });
};
exports.listcid1 = (req, res) => {
   connection.query('select client_id,first from demographics_with_product_id ',function (error, results, fields) {
    if (error) throw error;
    res.end(JSON.stringify(results));
  });
};
exports.cid = (req, res) => {
   connection.query('select client_id from demographics_with_product_id where client_id=?', [req.params.client_id],function (error, results, fields) {
    if (error) throw error;
    res.end(JSON.stringify(results));
  });
};

exports.categorytop5 = (req, res) => {
   connection.query('SELECT TRANS_LATITUDE,TRANS_LONGITUDE,BILLING_PLACE,CATEGORY,CLIENT_ID,DATE_FORMAT(TRANSACTION_DATE,"%Y-%m-%d") as TRANSACTION_DATE,sum(AMOUNT) as AMOUNT,max(AMOUNT) as MAX_AMOUNT FROM transaction where CLIENT_ID=? and TRANSACTION_DATE >= date_sub(CURDATE(), interval 3 year) GROUP BY CATEGORY order by sum(AMOUNT) desc limit 5',[req.params.CLIENT_ID],function (error, results, fields) {
    if (error) throw error;
    res.end(JSON.stringify(results));
  });
};

exports.mapplot = (req, res) => {
   connection.query('SELECT TRANS_LATITUDE,TRANS_LONGITUDE,BILLING_PLACE,CATEGORY,CLIENT_ID,DATE_FORMAT(TRANSACTION_DATE,"%Y-%m-%d") as TRANSACTION_DATE,AMOUNT FROM transaction where CLIENT_ID=? and TRANSACTION_DATE >= date_sub(CURDATE(), interval 3 year)',[req.params.CLIENT_ID],function (error, results, fields) {
    if (error) throw error;
    res.end(JSON.stringify(results));
  });
};


exports.categorytop10 = (req, res) => {
   connection.query('SELECT TRANS_LATITUDE,TRANS_LONGITUDE,BILLING_PLACE,CATEGORY,client_id,DATE,sum(AMOUNT) as AMOUNT FROM persona_weighted_transaction where CLIENT_ID=? GROUP BY CATEGORY order by sum(AMOUNT) desc limit 10',[req.params.CLIENT_ID],function (error, results, fields) {
    if (error) throw error;
    res.end(JSON.stringify(results));
  });
};

exports.getmapdetails = (req, res) => {
  connection.query('SELECT TRANS_LATITUDE,TRANS_LONGITUDE,CATEGORY FROM persona_weighted_transaction limit 50',function (error, results, fields) {
   if (error) throw error;
   res.end(JSON.stringify(results));
 });
};

exports.categorytop5withdate = (req, res) => {
   connection.query('SELECT TRANS_LATITUDE,TRANS_LONGITUDE,BILLING_PLACE,CATEGORY,CLIENT_ID,DATE_FORMAT(TRANSACTION_DATE,"%Y-%m-%d") as TRANSACTION_DATE,sum(AMOUNT) as AMOUNT FROM transaction where CLIENT_ID=? GROUP BY CATEGORY order by sum(AMOUNT) desc limit 5',[req.params.CLIENT_ID],function (error, results, fields) {
    if (error) throw error;
    res.end(JSON.stringify(results));
  });
};
